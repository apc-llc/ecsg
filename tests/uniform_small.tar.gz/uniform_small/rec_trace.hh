in=rec_trace.asci n1=3 n2=4 data_format=ascii_float
2.0	sfdd	ecsg/tests/uniform:	marcusmae@M17xR4	Wed Nov 22 11:55:59 2017

	data_format="native_float"
	esize=4
	in="stdout"
	in="stdin"

 �ZD  HDUUiBU�oD  HDUUiB�*�D  HDUUiBU��D  HDUUiB